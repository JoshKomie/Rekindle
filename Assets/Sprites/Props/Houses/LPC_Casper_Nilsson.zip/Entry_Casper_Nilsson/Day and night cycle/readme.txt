This is a gradient for a day and night cycle. If you collect all shadows to a single tileset
and make an opacity changing sprite that work the same way as the day and night gradient,
then you will get a nice feeling of lower contrast at night. Add some glowing windows on 
the buildings, street lights and burning torches. :)